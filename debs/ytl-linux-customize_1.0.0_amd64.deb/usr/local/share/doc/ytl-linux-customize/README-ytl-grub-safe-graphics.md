# ytl-grub-safe-graphics

Scripts to add/remove `nomodeset` kernel parameter at `/etc/default/grub`

## Acknowledgement

Icon designed by [photo3idea-studio](https://www.flaticon.com/authors/photo3idea-studio) downloaded from [Flaticon](https://www.flaticon.com/free-icon/3d-graphics_3163382).
